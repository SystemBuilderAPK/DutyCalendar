package com.example.dutycalendar

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.widget.Toast

/**
 * Plays a duty alarm using Android's dedicated ALARM audio usage.
 * Snooze schedules the same alarm again after 10 minutes.
 */
class AlarmSoundService : Service() {

    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAlarm()
                return START_NOT_STICKY
            }

            ACTION_SNOOZE -> {
                val title = intent.getStringExtra(EXTRA_ALARM_TITLE) ?: "Duty Alarm"
                val toneString = intent.getStringExtra(EXTRA_TONE_URI)
                scheduleSnooze(title, toneString)
                stopAlarm()
                return START_NOT_STICKY
            }
        }

        val title = intent?.getStringExtra(EXTRA_ALARM_TITLE) ?: "Duty Alarm"
        val toneString = intent?.getStringExtra(EXTRA_TONE_URI)

        val notification = buildNotification(title, toneString)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        playAlarm(toneString)
        return START_NOT_STICKY
    }

    private fun scheduleSnooze(title: String, toneString: String?) {
        val alarmManager = getSystemService(AlarmManager::class.java)
        val triggerAt = System.currentTimeMillis() + SNOOZE_MINUTES * 60_000L

        val alarmIntent = Intent(this, DutyAlarmReceiver::class.java).apply {
            action = DutyAlarmReceiver.ACTION_DUTY_ALARM
            putExtra(EXTRA_ALARM_TITLE, title)
            putExtra(EXTRA_TONE_URI, toneString)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            SNOOZE_REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        try {
            // Android 12+ may deny exact alarms unless the user grants
            // Alarms & reminders access. In that case, use an inexact fallback.
            val exactAlarmAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                    alarmManager.canScheduleExactAlarms()

            if (exactAlarmAllowed) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAt,
                            pendingIntent
                        )
                    } else {
                        alarmManager.setExact(
                            AlarmManager.RTC_WAKEUP,
                            triggerAt,
                            pendingIntent
                        )
                    }
                } catch (_: SecurityException) {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt,
                    pendingIntent
                )
            }

            Toast.makeText(
                this,
                "Alarm snoozed for $SNOOZE_MINUTES minutes",
                Toast.LENGTH_SHORT
            ).show()
        } catch (_: Exception) {
            Toast.makeText(
                this,
                "Unable to schedule snooze. Please check alarm permissions.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun playAlarm(toneString: String?) {
        stopPlayerOnly()

        val toneUri = try {
            if (!toneString.isNullOrBlank()) {
                Uri.parse(toneString)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            }
        } catch (_: Exception) {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        } ?: return

        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmSoundService, toneUri)
                isLooping = true
                setOnErrorListener { player, _, _ ->
                    try {
                        player.release()
                    } catch (_: Exception) {
                    }
                    if (mediaPlayer === player) mediaPlayer = null
                    true
                }
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopPlayerOnly()
            stopSelf()
        }
    }

    private fun stopPlayerOnly() {
        val player = mediaPlayer
        mediaPlayer = null
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
    }

    private fun stopAlarm() {
        stopPlayerOnly()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Duty alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Ongoing notification while a duty alarm is sounding"
                setSound(null, null)
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, toneString: String?): Notification {
        val dismissIntent = Intent(this, AlarmSoundService::class.java).apply {
            action = ACTION_STOP
        }
        val dismissPendingIntent = PendingIntent.getService(
            this,
            STOP_REQUEST_CODE,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val snoozeIntent = Intent(this, AlarmSoundService::class.java).apply {
            action = ACTION_SNOOZE
            putExtra(EXTRA_ALARM_TITLE, title)
            putExtra(EXTRA_TONE_URI, toneString)
        }
        val snoozePendingIntent = PendingIntent.getService(
            this,
            SNOOZE_ACTION_REQUEST_CODE,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val fullScreenIntent = Intent(this, AlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ALARM_TITLE, title)
            putExtra(EXTRA_TONE_URI, toneString)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            FULL_SCREEN_REQUEST_CODE,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("Duty alarm is ringing")
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .addAction(
                android.R.drawable.ic_media_pause,
                "Snooze 10 min",
                snoozePendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Dismiss",
                dismissPendingIntent
            )
            .build()
    }

    override fun onDestroy() {
        stopPlayerOnly()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.dutycalendar.action.START_ALARM"
        const val ACTION_STOP = "com.example.dutycalendar.action.STOP_ALARM"
        const val ACTION_SNOOZE = "com.example.dutycalendar.action.SNOOZE_ALARM"
        const val EXTRA_TONE_URI = "extra_tone_uri"
        const val EXTRA_ALARM_TITLE = "extra_alarm_title"

        private const val CHANNEL_ID = "duty_alarm_playback"
        private const val NOTIFICATION_ID = 4101
        private const val STOP_REQUEST_CODE = 4102
        private const val SNOOZE_ACTION_REQUEST_CODE = 4103
        private const val SNOOZE_REQUEST_CODE = 4104
        private const val FULL_SCREEN_REQUEST_CODE = 4105
        private const val SNOOZE_MINUTES = 10
    }
}
