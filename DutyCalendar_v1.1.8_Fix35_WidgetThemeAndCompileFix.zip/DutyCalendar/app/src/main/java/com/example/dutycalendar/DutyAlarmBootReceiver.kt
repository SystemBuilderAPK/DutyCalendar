package com.example.dutycalendar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.AlarmManager
import android.os.Build

class DutyAlarmBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val saved = DutyDataStore.load(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(AlarmManager::class.java)
            if (!manager.canScheduleExactAlarms()) return
        }

        saved.assigned.forEach { (date, ids) ->
            ids.forEach { id ->
                val config = saved.configs.firstOrNull { it.id == id }
                if (config != null && config.time.isNotBlank()) {
                    DutyAlarmScheduler.schedule(context, date, config)
                }
            }
        }
    }
}
