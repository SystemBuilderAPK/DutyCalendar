package com.example.dutycalendar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedDutyData(
    val configs: List<DutyConfig>,
    val assigned: Map<String, Set<Int>>,
    val nextId: Int
)

object DutyDataStore {
    private const val PREFS = "duty_alarm_data"
    private const val KEY_DATA = "saved_data"

    fun load(context: Context): SavedDutyData {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DATA, null) ?: return SavedDutyData(emptyList(), emptyMap(), 5)

        return try {
            val root = JSONObject(raw)
            val configsJson = root.optJSONArray("configs") ?: JSONArray()
            val configs = buildList {
                for (i in 0 until configsJson.length()) {
                    val item = configsJson.getJSONObject(i)
                    add(
                        DutyConfig(
                            id = item.getInt("id"),
                            name = item.getString("name"),
                            time = item.optString("time", ""),
                            color = item.optInt("color", 0),
                            toneUri = item.optString("toneUri").takeIf { it.isNotBlank() && it != "null" }
                        )
                    )
                }
            }

            val assignmentsJson = root.optJSONObject("assigned") ?: JSONObject()
            val assigned = mutableMapOf<String, Set<Int>>()
            val keys = assignmentsJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val idsJson = assignmentsJson.optJSONArray(key) ?: JSONArray()
                val ids = buildSet {
                    for (i in 0 until idsJson.length()) add(idsJson.getInt(i))
                }
                assigned[key] = ids
            }

            SavedDutyData(configs, assigned, root.optInt("nextId", 5))
        } catch (_: Exception) {
            SavedDutyData(emptyList(), emptyMap(), 5)
        }
    }

    fun save(
        context: Context,
        configs: List<DutyConfig>,
        assigned: Map<String, Set<Int>>,
        nextId: Int,
        refreshWidgets: Boolean = true
    ) {
        val configsJson = JSONArray()
        configs.forEach { config ->
            configsJson.put(
                JSONObject().apply {
                    put("id", config.id)
                    put("name", config.name)
                    put("time", config.time)
                    put("color", config.color)
                    put("toneUri", config.toneUri)
                }
            )
        }

        val assignedJson = JSONObject()
        assigned.forEach { (date, ids) ->
            val idsJson = JSONArray()
            ids.forEach { idsJson.put(it) }
            assignedJson.put(date, idsJson)
        }

        val root = JSONObject().apply {
            put("configs", configsJson)
            put("assigned", assignedJson)
            put("nextId", nextId)
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_DATA, root.toString())
            .apply()
        if (refreshWidgets) DutyCalendarWidgetProvider.refreshAll(context)
    }
}
