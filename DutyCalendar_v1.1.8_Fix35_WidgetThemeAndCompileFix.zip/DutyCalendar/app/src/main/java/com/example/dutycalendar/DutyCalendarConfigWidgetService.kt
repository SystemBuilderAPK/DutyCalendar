package com.example.dutycalendar

import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import android.graphics.Color
import java.util.Calendar

class DutyCalendarConfigWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = ConfigFactory(applicationContext)

    private class ConfigFactory(private val context: Context) : RemoteViewsFactory {
        private var configs: List<DutyConfig> = emptyList()
        private var assigned: Set<Int> = emptySet()
        private var dark = false
        override fun onCreate() = Unit
        override fun onDataSetChanged() {
            val data = DutyDataStore.load(context)
            configs = data.configs
            val prefs = context.getSharedPreferences("duty_calendar_widget", Context.MODE_PRIVATE)
            val today = Calendar.getInstance().let { String.format(java.util.Locale.US, "%04d-%02d-%02d", it.get(Calendar.YEAR), it.get(Calendar.MONTH)+1, it.get(Calendar.DAY_OF_MONTH)) }
            val selected = prefs.getString("selected_date", today) ?: today
            assigned = data.assigned[selected].orEmpty()
            dark = context.getSharedPreferences("duty_alarm_settings", Context.MODE_PRIVATE).getBoolean("dark_theme", false)
        }
        override fun getCount() = configs.size
        override fun getViewAt(position: Int): RemoteViews? {
            val config = configs.getOrNull(position) ?: return null
            val row = RemoteViews(context.packageName, R.layout.widget_config_row)
            val checked = config.id in assigned
            row.setTextViewText(R.id.widget_config_name, (if (checked) "✓  " else "＋  ") + config.name)
            row.setTextViewText(R.id.widget_config_time, config.time)
            val colors = listOf(0xFFFFE1E1.toInt(),0xFFDCE9FF.toInt(),0xFFFFF1C9.toInt(),0xFFDDF3E4.toInt(),0xFFFFE6D5.toInt(),0xFFE5E7EB.toInt())
            val color = colors.getOrElse(config.color) { 0xFFE5E7EB.toInt() }
            row.setInt(R.id.widget_config_name, "setBackgroundColor", color)
            row.setTextColor(R.id.widget_config_name, Color.BLACK)
            row.setTextColor(R.id.widget_config_time, if (dark) Color.LTGRAY else Color.DKGRAY)
            row.setOnClickFillInIntent(R.id.widget_config_name, Intent().putExtra(DutyCalendarWidgetProvider.EXTRA_CONFIG_ID, config.id))
            return row
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = configs.getOrNull(position)?.id?.toLong() ?: position.toLong()
        override fun hasStableIds() = true
        override fun onDestroy() { configs = emptyList() }
    }
}
