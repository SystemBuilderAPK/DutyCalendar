package com.example.dutycalendar

import android.os.Bundle
import android.app.AlarmManager
import android.app.PendingIntent
import android.provider.Settings
import android.os.Build
import android.app.Activity
import android.app.NotificationManager
import android.os.PowerManager
import android.content.pm.PackageManager
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.widget.NumberPicker
import android.widget.LinearLayout
import androidx.compose.ui.viewinterop.AndroidView

private val Blue = Color(0xFF2866D8)
private val DarkBlue = Color(0xFF173D80)
private val Page = Color(0xFFF3F6FB)
private val Ink = Color(0xFF172033)
private val Muted = Color(0xFF667085)
private val ScheduleBackgrounds = listOf(
    Color(0xFFFFE1E1), // Red
    Color(0xFFDCE9FF), // Blue
    Color(0xFFFFF1C9), // Yellow
    Color(0xFFDDF3E4), // Green
    Color(0xFFFFE6D5), // Orange
    Color(0xFFE5E7EB)  // Grey
)
private val ScheduleTexts = listOf(
    Color(0xFF963B3B),
    Color(0xFF234A85),
    Color(0xFF806016),
    Color(0xFF286044),
    Color(0xFF92502A),
    Color(0xFF667085)  // Grey
)
private val ScheduleColorNames = listOf("Red", "Blue", "Yellow", "Green", "Orange", "Grey")

data class DutyConfig(
    val id: Int,
    val name: String,
    val time: String,
    val color: Int = 0,
    val toneUri: String? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                DutyAlarmApp()
            }
        }
    }
}


private val filipinoUi = mapOf(
    "Home" to "Home", "Configs" to "Mga Schedule", "Calendar" to "Kalendaryo",
    "Your schedule, organized." to "Maayos na nakaplano ang iyong duty.",
    "NEXT UPCOMING ALARM" to "SUSUNOD NA ALARM", "No alarm" to "Walang alarm",
    "Next Upcoming Alarm" to "Susunod na Alarm",
    "Next After That" to "Kasunod na Alarm",
    "Saved Configs" to "Mga Naka-save na Config",
    "Upcoming Schedules" to "Mga Paparating na Schedule",
    "TODAY" to "NGAYON",
    "TOMORROW" to "BUKAS",
    "Add a schedule" to "Magdagdag ng schedule",

    "No scheduled duty" to "Walang nakatalagang duty",
    "Add a schedule in Calendar" to "Magdagdag ng schedule sa Kalendaryo",
    "TIME REMAINING" to "NATITIRANG ORAS",
    "No upcoming alarm" to "Walang susunod na alarm",
    "DAYS : HOURS : MINUTES : SECONDS" to "ARAW : ORAS : MINUTO : SEGUNDO",
    "HOURS : MINUTES : SECONDS" to "ORAS : MINUTO : SEGUNDO",
    "NEXT AFTER THAT" to "SUSUNOD PAGKATAPOS NITO",
    "No next alarm" to "Wala nang kasunod na alarm",
    "SAVED CONFIGS" to "NA-save NA MGA SCHEDULE",
    "Schedule options" to "Mga pagpipilian sa schedule",
    "Upcoming Schedule" to "Mga Paparating na Schedule",
    "Upcoming Schedules" to "Mga Paparating na Schedule",
    "No upcoming schedules." to "Walang paparating na schedule.",
    "Schedule Configs" to "Mga Schedule",
    "Edit once to update every assigned date." to "I-edit nang isang beses para ma-update ang lahat ng petsang naka-assign.",
    "Long-press a Config to select it, scroll to the destination, then tap another Config to move the selected one below it." to "I-long-press ang Config para piliin ito, mag-scroll sa target, pagkatapos ay i-tap ang ibang Config para mailipat ang napili sa ilalim nito.",
    "+ Add" to "+ Magdagdag", "+ Add / Assign Schedule" to "+ Magdagdag / Magtalaga ng Schedule",
    "+ Add Entry" to "+ Magdagdag ng Entry", "+ Assign Configs" to "+ Magtalaga ng mga Schedule",
    "Tap a date to manage schedules." to "Pindutin ang petsa para pamahalaan ang mga schedule.",
    "Assigned entries" to "Mga nakatalagang entry",
    "No schedule assigned yet." to "Wala pang nakatalagang schedule.",
    "Remove" to "Alisin", "Assign Schedules" to "Magtalaga ng mga Schedule",
    "Save Assignment" to "I-save ang Pagtatalaga",
    "Add Entry" to "Magdagdag ng Entry", "Add Schedule" to "Magdagdag ng Schedule",
    "Edit Schedule" to "I-edit ang Schedule", "Delete Schedule?" to "Burahin ang Schedule?",
    "Schedule name" to "Pangalan ng Schedule", "e.g. Morning Duty" to "hal. Morning Duty",
    "Schedule color" to "Kulay ng Schedule", "Alarm tone" to "Tunog ng Alarm",
    "Choose tone" to "Pumili ng Tunog", "▶ Preview" to "▶ Pakinggan",
    "Use default tone" to "Gamitin ang default na tunog",
    "Alarm time (optional)" to "Oras ng Alarm (opsyonal)",
    "Save" to "I-save", "Cancel" to "Kanselahin", "Edit" to "I-edit", "Delete" to "Burahin",
    "Settings" to "Mga Setting", "Help & how to use the app" to "Tulong at kung paano gamitin ang app",
    "Step-by-step guide for Configs, Calendar, alarms, and permissions." to "Gabay sa paggamit ng mga schedule, kalendaryo, alarm, at pahintulot.",
    "Open Help / User Guide" to "Buksan ang Gabay sa Paggamit",
    "Language" to "Wika", "Language / Wika" to "Wika",
    "Choose the language used in app guides and explanations." to "Piliin ang wikang gagamitin sa buong app.",
    "Appearance" to "Hitsura", "Appearance / Hitsura" to "Hitsura",
    "Choose your preferred app theme." to "Piliin ang gusto mong tema ng app.",
    "Light" to "Maliwanag", "Dark" to "Madilim",
    "Alarm permissions" to "Mga pahintulot ng Alarm",
    "Enable these settings so alarms can ring on time and show the Snooze/Dismiss screen." to "I-enable ang mga setting na ito para tumunog ang alarm sa tamang oras at lumabas ang Snooze/Dismiss screen.",
    "Allowed" to "Pinapayagan", "Needs attention" to "Kailangang ayusin",
    "Enable" to "I-enable", "View" to "Tingnan", "Done" to "Tapos na",
    "Check again" to "Suriin muli", "Open Settings" to "Buksan ang Settings",
    "Phone-specific background protection" to "Proteksyon sa background ayon sa phone",
    "Permission help" to "Tulong sa Pahintulot", "Got it" to "Naintindihan",
    "Duty Calendar — User Guide" to "Duty Calendar — Gabay sa Paggamit",
    "1. CONFIGS" to "1. MGA SCHEDULE", "2. CALENDAR" to "2. KALENDARYO",
    "3. ALARMS" to "3. MGA ALARM", "4. PERMISSIONS" to "4. MGA PAHINTULOT",
    "5. PHONE BACKGROUND PROTECTION" to "5. PROTEKSYON SA BACKGROUND NG PHONE",
    "Reorder schedules" to "Baguhin ang Ayos ng mga Schedule",
    "Long-press the ☰ handle on the left of a schedule, then drag it up or down. The new order is saved automatically and does not change date assignments." to "Pindutin nang matagal ang ☰ handle sa kaliwa ng schedule, saka i-drag pataas o pababa. Awtomatikong mase-save ang bagong ayos at hindi mababago ang mga nakatalagang petsa.",
    "Open Configs and tap Add Config to create a schedule. Enter its name, alarm time (12-hour AM/PM), color, and ringtone. Editing a config updates the dates assigned to it. Deleting a config also removes its calendar assignments." to "Buksan ang Mga Schedule at pindutin ang Magdagdag para gumawa ng schedule. Ilagay ang pangalan, oras ng alarm (AM/PM), kulay, at ringtone. Kapag in-edit ang schedule, maa-update ang lahat ng petsang naka-assign dito. Kapag binura, aalisin din ito sa kalendaryo.",
    "Select a date in Calendar. Tap Assign Configs to choose one or more schedules. Their names appear in the date cell. Open the date again whenever you need to change its assignments." to "Pumili ng petsa sa Kalendaryo. Pindutin ang Magtalaga ng mga Schedule para pumili ng isa o higit pang schedule. Lalabas ang mga pangalan sa kahon ng petsa. Buksan muli ang petsa para baguhin ang mga nakatalaga.",
    "Each assigned config with an alarm time schedules an alarm. You can choose and preview a ringtone in the config. On the alarm screen, Snooze adds 10 minutes; Dismiss stops only the current alarm and does not delete the schedule." to "Bawat nakatalagang schedule na may oras ay magkakaroon ng alarm. Maaari kang pumili at makinig muna ng ringtone. Sa alarm screen, ang Snooze ay magdadagdag ng 10 minuto; ang Dismiss ay titigil lamang sa kasalukuyang alarm at hindi magbubura ng schedule.",
    "In Gear / Settings, check the status of each permission. Tap ⓘ for an explanation, or Enable / View to open the relevant Android settings. After changing a permission, return to the app and check its status again." to "Sa Gear / Mga Setting, tingnan ang status ng bawat pahintulot. Pindutin ang ⓘ para sa paliwanag, o ang Enable / View para buksan ang kaukulang Android settings. Pagkatapos magbago ng pahintulot, bumalik sa app at suriin muli ang status.",
    "Some phone brands have their own cleaner or Super Clean feature that may force-stop apps. Follow the brand-specific guide in Gear / Settings and remove Duty Calendar from the cleanup list if that option is available. Menu names may vary by phone model and Android version." to "May ilang brand ng phone na may sariling cleaner o Super Clean na maaaring mag-force-stop ng apps. Sundin ang gabay para sa brand sa Gear / Settings at alisin ang Duty Calendar sa cleanup list kung may ganitong opsyon. Maaaring mag-iba ang pangalan ng menu depende sa modelo at bersyon ng Android.",
    "Close" to "Isara", "Morning Duty" to "Morning Duty", "Afternoon Duty" to "Afternoon Duty",
    "Night Duty" to "Night Duty", "Day Off" to "Day Off",
    "Red" to "Pula", "Blue" to "Asul", "Yellow" to "Dilaw", "Green" to "Berde", "Orange" to "Kahel",
    "NEXT AFTER THAT" to "SUSUNOD PAGKATAPOS NITO",
    "No next alarm" to "Wala nang kasunod na alarm",
    "SAVED CONFIGS" to "NA-SAVE NA MGA SCHEDULE",
    "Schedule options" to "Mga pagpipilian sa schedule",
    "No alarm" to "Walang alarm",
    "Alarms & reminders" to "Mga Alarm at Paalala",
    "Notifications" to "Mga Notification",
    "Full-screen alarm" to "Full-screen na Alarm",
    "Battery optimization exemption" to "Pag-aalis sa Battery Optimization",
    "Needs attention" to "Kailangang ayusin",
    "Exact alarms: open Alarms & reminders / Schedule exact alarms for Duty Calendar and enable Allow. This lets alarms ring at the scheduled time." to "Exact alarms: buksan ang Alarms & reminders / Schedule exact alarms para sa Duty Calendar at i-enable ang Allow. Kailangan ito para tumunog ang alarm sa nakatakdang oras.",
    "Notifications: open App notifications for Duty Calendar and enable Allow notifications. This is needed to show alarm notifications and controls." to "Notifications: buksan ang App notifications para sa Duty Calendar at i-enable ang Allow notifications. Kailangan ito para makita ang alarm notification at mga control.",
    "Full-screen alarm: under Special app access / Full-screen notifications, select Duty Calendar and allow full-screen display if available. This helps show the alarm screen over the lock screen." to "Full-screen alarm: sa Special app access / Full-screen notifications, piliin ang Duty Calendar at payagan ang full-screen display kung available. Nakakatulong ito para lumabas ang alarm screen kahit naka-lock ang phone.",
    "Battery: open Battery optimization or App battery usage for Duty Calendar. Choose Unrestricted / Don't optimize / Allow background activity if available. This cannot override a true system Force stop or a phone's own cleanup feature." to "Battery: buksan ang Battery optimization o App battery usage para sa Duty Calendar. Piliin ang Unrestricted / Don't optimize / Allow background activity kung available. Hindi nito mapipigilan ang system Force stop o sariling cleanup feature ng phone.",
    "Menu names vary by phone model and Android version. These settings help prevent automatic cleanup; no app can override a true system Force stop or a user-disabled alarm permission." to "Maaaring mag-iba ang pangalan ng menu depende sa modelo ng phone at bersyon ng Android. Nakakatulong ang mga setting na ito laban sa automatic cleanup, pero walang app na makakapigil sa tunay na system Force stop o pahintulot na pinatay ng user."
)

private fun dutyUi(text: String, filipino: Boolean): String =
    if (filipino) filipinoUi[text] ?: text else text

@Composable
private fun LiveCalendarIcon(
    currentTimeMillis: Long,
    darkTheme: Boolean,
    modifier: Modifier = Modifier
) {
    val todayDayNumber = Calendar.getInstance().apply { timeInMillis = currentTimeMillis }
        .get(Calendar.DAY_OF_MONTH)
    val todayMonthName = SimpleDateFormat("MMM", Locale.US).format(Date(currentTimeMillis))

    Box(
        modifier.size(width = 48.dp, height = 54.dp)
            .border(
                1.dp,
                if (darkTheme) Color(0xFF8993A3) else Color(0xFFB8B8B8),
                RoundedCornerShape(5.dp)
            )
            .background(Color.White, RoundedCornerShape(5.dp))
            .clip(RoundedCornerShape(5.dp))
    ) {
        Column(Modifier.fillMaxSize()) {
            BoxWithConstraints(
                Modifier.fillMaxWidth().height(22.dp)
                    .background(Color(0xFFEF3F36)),
                contentAlignment = Alignment.Center
            ) {
                val density = androidx.compose.ui.platform.LocalDensity.current
                val textMeasurer = rememberTextMeasurer()
                val baseMonthSp = 12f
                val measuredMonth = textMeasurer.measure(
                    text = todayMonthName,
                    style = TextStyle(fontSize = baseMonthSp.sp, fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    softWrap = false
                )
                val availableWidthPx = with(density) { (maxWidth - 2.dp).coerceAtLeast(1.dp).toPx() }
                val availableHeightPx = with(density) { 20.dp.toPx() }
                val monthFitRatio = minOf(
                    1f,
                    availableWidthPx / measuredMonth.size.width.coerceAtLeast(1),
                    availableHeightPx / measuredMonth.size.height.coerceAtLeast(1)
                )
                val monthFontSp = (baseMonthSp * monthFitRatio).coerceAtLeast(3.5f).sp
                Text(
                    todayMonthName,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 1.dp),
                    color = Color.White,
                    fontSize = monthFontSp,
                    lineHeight = monthFontSp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Clip,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            BoxWithConstraints(
                Modifier.fillMaxSize().background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                val systemFontScale = androidx.compose.ui.platform.LocalDensity.current.fontScale
                val dayText = todayDayNumber.toString()
                val widthFitSp = maxWidth.value / (dayText.length * 0.66f * systemFontScale)
                val heightFitSp = maxHeight.value / (1.18f * systemFontScale)
                val dayFontSp = minOf(29f, widthFitSp, heightFitSp).coerceAtLeast(12f).sp
                Text(
                    dayText,
                    color = Color.Black,
                    fontSize = dayFontSp,
                    lineHeight = dayFontSp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 5.dp).offset(y = (-3).dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(Modifier.size(7.dp).background(Color(0xFF171717), RoundedCornerShape(50)))
            Box(Modifier.size(7.dp).background(Color(0xFF171717), RoundedCornerShape(50)))
        }
    }
}

@Composable
private fun TodayNeonFrame(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.drawBehind {
            val inset = 3.5.dp.toPx()
            val rectSize = androidx.compose.ui.geometry.Size(
                (size.width - inset * 2).coerceAtLeast(0f),
                (size.height - inset * 2).coerceAtLeast(0f)
            )
            val corner = androidx.compose.ui.geometry.CornerRadius(9.dp.toPx())
            val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)

            // Soft outer glow, then a crisp neon edge, all measured from the actual cell bounds.
            drawRoundRect(
                color = Color(0xFF00AFFF).copy(alpha = 0.30f),
                topLeft = topLeft,
                size = rectSize,
                cornerRadius = corner,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 7.dp.toPx())
            )
            drawRoundRect(
                color = Color(0xFF007BFF),
                topLeft = topLeft,
                size = rectSize,
                cornerRadius = corner,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4.dp.toPx())
            )
            drawRoundRect(
                color = Color(0xFF8DEBFF),
                topLeft = topLeft,
                size = rectSize,
                cornerRadius = corner,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.4.dp.toPx())
            )
        }
    ) {
        BoxWithConstraints(
            Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-1).dp)
                .fillMaxWidth(0.82f)
        ) {
            val density = androidx.compose.ui.platform.LocalDensity.current
            val fontScale = density.fontScale
            val textMeasurer = rememberTextMeasurer()
            val pillHeight = (18f * fontScale).coerceIn(18f, 30f).dp
            val badgeText = "TODAY"
            val baseBadgeSp = 8f
            val measuredBadge = textMeasurer.measure(
                text = badgeText,
                style = TextStyle(fontSize = baseBadgeSp.sp, fontWeight = FontWeight.ExtraBold),
                maxLines = 1,
                softWrap = false
            )
            val badgeWidthPx = with(density) { (maxWidth - 8.dp).coerceAtLeast(1.dp).toPx() }
            val badgeHeightPx = with(density) { (pillHeight - 4.dp).coerceAtLeast(1.dp).toPx() }
            val badgeFitRatio = minOf(
                1f,
                badgeWidthPx / measuredBadge.size.width.coerceAtLeast(1),
                badgeHeightPx / measuredBadge.size.height.coerceAtLeast(1)
            )
            val labelFontSp = (baseBadgeSp * badgeFitRatio).coerceAtLeast(3.5f).sp

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(pillHeight)
                    .background(Color(0xFF063DAD), RoundedCornerShape(50))
                    .border(1.dp, Color(0xFF35D9FF), RoundedCornerShape(50))
                    .padding(horizontal = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = badgeText,
                    color = Color.White,
                    fontSize = labelFontSp,
                    lineHeight = labelFontSp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Clip,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun DutyAlarmApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val themePrefs = remember {
        context.getSharedPreferences("duty_alarm_settings", android.content.Context.MODE_PRIVATE)
    }
    var darkTheme by remember {
        mutableStateOf(themePrefs.getBoolean("dark_theme", false))
    }
    val systemLanguage = remember { Locale.getDefault().language }
    var appLanguage by remember {
        mutableStateOf(themePrefs.getString("app_language", if (systemLanguage == "fil" || systemLanguage == "tl") "fil" else "en") ?: "en")
    }
    val isFilipino = appLanguage == "fil"
    var showSettings by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var permissionHelpTopic by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf("") }
    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Config reorder uses a simple select-then-place interaction.
    val configScrollState = rememberScrollState()
    var selectedConfigId by remember { mutableStateOf<Int?>(null) }

    // Keep the live countdown refreshed while the main UI is visible, but
    // pause the app-wide tick while an editor/dialog is open. This prevents
    // unrelated one-second recompositions from disturbing AndroidView inputs
    // such as the editable NumberPicker time fields.
    LaunchedEffect(dialog) {
        if (dialog.isBlank()) {
            while (true) {
                currentTimeMillis = System.currentTimeMillis()
                delay(1000L)
            }
        } else {
            // Refresh immediately when the dialog closes; the next effect
            // iteration will resume the normal one-second countdown tick.
            currentTimeMillis = System.currentTimeMillis()
        }
    }

    val Page = if (darkTheme) Color(0xFF000000) else Color(0xFFF3F6FB)
    val Ink = if (darkTheme) Color(0xFFF1F5F9) else Color(0xFF172033)
    val Muted = if (darkTheme) Color(0xFFB0BAC8) else Color(0xFF667085)
    val surfaceColor = if (darkTheme) Color(0xFF050505) else Color.White
    val softCellColor = if (darkTheme) Color(0xFF1C1C1C) else Color(0xFFF5F7FB)
    val selectedCellColor = if (darkTheme) Color.White else Color(0xFFEAF1FF)
    val navColor = if (darkTheme) Color(0xFF1B2534) else Color.White

    var previewRingtone by remember { mutableStateOf<Ringtone?>(null) }

    fun stopTonePreview() {
        try { previewRingtone?.stop() } catch (_: Exception) { }
        previewRingtone = null
    }

    fun previewTone(uriString: String?) {
        stopTonePreview()
        val uri = try {
            uriString?.let { Uri.parse(it) }
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        } catch (_: Exception) {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        } ?: return

        try {
            val ringtone = RingtoneManager.getRingtone(context, uri) ?: return
            ringtone.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            previewRingtone = ringtone
            ringtone.play()
        } catch (_: Exception) {
            stopTonePreview()
        }
    }

    DisposableEffect(Unit) {
        onDispose { stopTonePreview() }
    }

    val savedData = remember { DutyDataStore.load(context) }
    val configs = remember {
        mutableStateListOf<DutyConfig>().apply {
            addAll(savedData.configs.ifEmpty {
                listOf(
                    DutyConfig(1, "Morning Duty", "05:00 AM", 0),
                    DutyConfig(2, "Afternoon Duty", "01:00 PM", 1),
                    DutyConfig(3, "Night Duty", "09:00 PM", 0),
                    DutyConfig(4, "Day Off", "", 1)
                )
            })
        }
    }

    val assigned = remember {
        mutableStateMapOf<String, Set<Int>>().apply {
            putAll(savedData.assigned)
        }
    }

    var nextId by remember { mutableIntStateOf(savedData.nextId.coerceAtLeast(5)) }
    var showExactAlarmHelp by remember { mutableStateOf(false) }

    fun rescheduleAll() {
        DutyDataStore.save(context, configs.toList(), assigned.toMap(), nextId)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                showExactAlarmHelp = true
                return
            }
        }
        DutyAlarmScheduler.cancelAll(context, assigned.toMap())
        assigned.forEach { (date, ids) ->
            ids.forEach { id ->
                val c = configs.find { it.id == id }
                if (c != null && c.time.isNotBlank()) {
                    DutyAlarmScheduler.schedule(context, date, c)
                }
            }
        }
    }

    LaunchedEffect(configs.toList(), assigned.toMap(), nextId) {
        rescheduleAll()
    }
    var tab by remember { mutableStateOf("Home") }

    val today = Calendar.getInstance()

    var year by remember { mutableIntStateOf(today.get(Calendar.YEAR)) }
    var month by remember { mutableIntStateOf(today.get(Calendar.MONTH)) }

    var selectedDate by remember {
        mutableStateOf(dateKey(today))
    }

    var editingId by remember { mutableIntStateOf(-1) }

    fun dateLabel(key: String): String {
        return try {
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key)
            SimpleDateFormat("EEEE, MMMM d, yyyy", if (isFilipino) Locale("fil", "PH") else Locale.US).format(date!!)
        } catch (_: Exception) {
            key
        }
    }

    fun config(id: Int) = configs.find { it.id == id }

    fun alarmTimeMillis(date: String, time: String): Long? {
        return try {
            SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US).apply {
                isLenient = false
            }.parse("$date $time")?.time
        } catch (_: Exception) {
            null
        }
    }

    fun sortedAlarms(): List<Triple<String, DutyConfig, String>> {
        return assigned.flatMap { (date, ids) ->
            ids.mapNotNull { id ->
                val c = config(id)
                if (c != null && c.time.isNotBlank()) {
                    Triple(date, c, c.time)
                } else null
            }
        }.filter { alarm ->
            val alarmMillis = alarmTimeMillis(alarm.first, alarm.third)
            alarmMillis != null && alarmMillis > currentTimeMillis
        }.sortedBy { alarmTimeMillis(it.first, it.third) ?: Long.MAX_VALUE }
    }

    fun sortedUpcomingSchedules(): List<Pair<String, DutyConfig>> {
        val todayKey = dateKey(Calendar.getInstance())
        return assigned.flatMap { (date, ids) ->
            ids.mapNotNull { id ->
                config(id)?.let { schedule -> date to schedule }
            }
        }.filter { (date, schedule) ->
            // Keep future OFF/day-off entries, but hide timed schedules once
            // their alarm time has passed (including earlier times today).
            if (date < todayKey) false
            else if (schedule.time.isBlank()) true
            else (alarmTimeMillis(date, schedule.time) ?: 0L) > currentTimeMillis
        }.sortedWith(
            compareBy<Pair<String, DutyConfig>> { it.first }
                .thenBy { it.second.time.isBlank() }
                .thenBy { alarmTimeMillis(it.first, it.second.time) ?: Long.MAX_VALUE }
        )
    }

    fun moveConfig(fromIndex: Int, toIndex: Int) {
        if (fromIndex !in configs.indices || toIndex !in configs.indices || fromIndex == toIndex) return
        val item = configs.removeAt(fromIndex)
        configs.add(toIndex, item)
        // DutyDataStore persists the new order through the existing save effect.
    }

    fun removeConfig(id: Int) {
        assigned.keys.toList().forEach { key ->
            DutyAlarmScheduler.cancel(context, key, id)
            assigned[key] = assigned[key].orEmpty() - id
        }
        configs.removeAll { it.id == id }
        rescheduleAll()
    }

    Scaffold(
        containerColor = Page,
        bottomBar = {
            NavigationBar(containerColor = navColor) {
                listOf("Home", "Configs", "Calendar").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Text(
                                when (item) {
                                    "Home" -> "⌂"
                                    "Configs" -> "⚙"
                                    else -> "▦"
                                },
                                fontSize = 20.sp
                            )
                        },
                        label = { Text(dutyUi(item, isFilipino)) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(configScrollState)
                .padding(16.dp)
        ) {
            if (tab != "Home") {
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 58.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Spacer(Modifier.width(44.dp))
                    Column(
                        Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            LiveCalendarIcon(currentTimeMillis, darkTheme)
                            Spacer(Modifier.width(8.dp))
                            Text("Duty Alarm", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        }
                        Text(dutyUi("Your schedule, organized.", isFilipino), color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(44.dp))
                }
                Spacer(Modifier.height(18.dp))
            }

            when (tab) {
                "Home" -> {
                    val alarms = sortedAlarms()
                    val upcomingSchedules = sortedUpcomingSchedules()
                    val first = alarms.getOrNull(0)
                    val second = alarms.getOrNull(1)
                    val homeBlue = Color(0xFF1769E8)
                    val homeBlueDark = Color(0xFF0750C8)
                    val homeCyan = Color(0xFF31BDF4)
                    val homePurple = Color(0xFF8744D6)
                    val rowSurface = if (darkTheme) Color(0xFF050505) else Color.White
                    val rowBorder = if (darkTheme) Color(0xFF454545) else Color(0xFFD8DCE2)
                    val homeText = if (darkTheme) Color.White else Color(0xFF111827)

                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 58.dp).padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showSettings = true }) {
                            Text("☰", color = homeText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.weight(1f))
                        LiveCalendarIcon(currentTimeMillis, darkTheme)
                        Spacer(Modifier.width(5.dp))
                        Text("🔔", fontSize = 22.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Duty Alarm",
                            modifier = Modifier.widthIn(max = 170.dp),
                            color = homeText,
                            fontSize = 25.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 2,
                            softWrap = true,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Clip
                        )
                        Spacer(Modifier.weight(1f))
                        Spacer(Modifier.width(44.dp))
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = homeBlue),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            .border(1.dp, if (darkTheme) homeCyan else Color(0xFFB6D5FF), RoundedCornerShape(20.dp))
                    ) {
                        Column(
                            Modifier.fillMaxWidth().background(
                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                    listOf(homeBlue, homeBlueDark)
                                )
                            ).padding(vertical = 12.dp, horizontal = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                dutyUi("Next Upcoming Alarm", isFilipino),
                                modifier = Modifier.fillMaxWidth(),
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                maxLines = 2,
                                softWrap = true
                            )
                            Text(
                                first?.second?.name ?: dutyUi("No upcoming alarm", isFilipino),
                                modifier = Modifier.fillMaxWidth(),
                                color = Color.White,
                                fontSize = 25.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                maxLines = 2,
                                softWrap = true
                            )
                            Column(
                                Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    "▣  ${first?.let { dateLabel(it.first) } ?: dutyUi("Add a schedule", isFilipino)}",
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 2,
                                    softWrap = true
                                )
                                Text(
                                    "◷  ${first?.third ?: "—"}",
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                            val firstRemaining = first?.let { alarmTimeMillis(it.first, it.third)?.minus(currentTimeMillis) }
                            if (firstRemaining != null) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "${dutyUi("TIME REMAINING", isFilipino)}  ${formatCountdown(firstRemaining)}",
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 2,
                                    softWrap = true
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (darkTheme) Color(0xFF104D83) else Color(0xFFE4F2FF)),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().border(
                            1.dp, if (darkTheme) Color(0xFF64B5F6) else Color(0xFF9CC9EB), RoundedCornerShape(18.dp)
                        )
                    ) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                dutyUi("Next After That", isFilipino),
                                modifier = Modifier.fillMaxWidth(),
                                color = if (darkTheme) Color.White else Color(0xFF17345D),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                maxLines = 2,
                                softWrap = true
                            )
                            Text(
                                second?.second?.name ?: dutyUi("No next alarm", isFilipino),
                                modifier = Modifier.fillMaxWidth(),
                                color = if (darkTheme) Color.White else Color(0xFF17345D),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                maxLines = 2,
                                softWrap = true
                            )
                            Column(
                                Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    "▣  ${second?.let { dateLabel(it.first) } ?: "—"}",
                                    modifier = Modifier.fillMaxWidth(),
                                    color = if (darkTheme) Color.White else Color(0xFF17345D),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 2,
                                    softWrap = true
                                )
                                Text(
                                    "◷  ${second?.third ?: "—"}",
                                    modifier = Modifier.fillMaxWidth(),
                                    color = if (darkTheme) Color.White else Color(0xFF17345D),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                            val secondRemaining = second?.let { alarmTimeMillis(it.first, it.third)?.minus(currentTimeMillis) }
                            if (secondRemaining != null) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "${dutyUi("TIME REMAINING", isFilipino)}  ${formatCountdown(secondRemaining)}",
                                    color = if (darkTheme) Color.White else Color(0xFF17345D),
                                    modifier = Modifier.fillMaxWidth(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 2,
                                    softWrap = true
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (darkTheme) Color(0xFF7133B8) else Color(0xFFF1E5FF)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, if (darkTheme) Color(0xFFB98BFF) else Color(0xFFD0A5EC), RoundedCornerShape(14.dp))
                    ) {
                        Text(
                            "⚙  ${dutyUi("Saved Configs", isFilipino)}: ${configs.size}",
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            color = if (darkTheme) Color.White else Color(0xFF552078),
                            fontSize = 19.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 2,
                            softWrap = true
                        )
                    }

                    Spacer(Modifier.height(14.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = rowSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, rowBorder)
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                                Text("▦", color = homeText, fontSize = 22.sp)
                                Spacer(Modifier.width(8.dp))
                                Text("${dutyUi("Upcoming Schedules", isFilipino)} (${upcomingSchedules.size})", color = homeText, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            if (upcomingSchedules.isEmpty()) {
                                Text(dutyUi("No upcoming schedules.", isFilipino), color = Muted, modifier = Modifier.padding(8.dp))
                            } else {
                                upcomingSchedules.take(10).forEach { schedule ->
                                    val scheduleDate = schedule.first
                                    val config = schedule.second
                                    val dateObj = try {
                                        SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(scheduleDate)
                                    } catch (_: Exception) { null }
                                    val scheduleLocale = if (isFilipino) Locale("fil", "PH") else Locale.US
                                    val dateDay = dateObj?.let { SimpleDateFormat("EEE", scheduleLocale).format(it) } ?: ""
                                    val dateMonth = dateObj?.let { SimpleDateFormat("MMM d", scheduleLocale).format(it) } ?: scheduleDate
                                    val dayMarker = when (scheduleDate) {
                                        dateKey(Calendar.getInstance()) -> "TODAY"
                                        dateKey(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }) -> "TOMORROW"
                                        else -> ""
                                    }
                                    val accent = ScheduleTexts[config.color.coerceIn(0, 5)]
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                            .border(1.dp, rowBorder, RoundedCornerShape(12.dp))
                                            .background(rowSurface, RoundedCornerShape(12.dp))
                                            .padding(horizontal = 7.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            Modifier.width(7.dp).height(38.dp)
                                                .background(accent, RoundedCornerShape(8.dp))
                                        )
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.width(70.dp)) {
                                            Text(dateDay, color = homeText, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 13.sp)
                                            Text(dateMonth, color = homeText, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 13.sp)
                                        }
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.Center
                                            ) {
                                                if (dayMarker.isNotEmpty()) {
                                                    Box(
                                                        Modifier.background(
                                                            if (dayMarker == "TODAY") Color(0xFF16A33A) else Color(0xFF1675E8),
                                                            RoundedCornerShape(8.dp)
                                                        ).padding(horizontal = 8.dp, vertical = 5.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            dutyUi(dayMarker, isFilipino),
                                                            color = Color.White,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            maxLines = 1,
                                                            softWrap = false
                                                        )
                                                    }
                                                    Spacer(Modifier.width(8.dp))
                                                }
                                                Text(
                                                    config.name,
                                                    color = homeText,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    lineHeight = 17.sp,
                                                    modifier = Modifier.weight(1f),
                                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                                    softWrap = true
                                                )
                                            }
                                            Spacer(Modifier.height(3.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.Center
                                            ) {
                                                if (config.time.isBlank()) {
                                                    Text("🔕", color = homeText, fontSize = 15.sp)
                                                    Spacer(Modifier.width(5.dp))
                                                    Text("—", color = homeText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                } else {
                                                    Image(
                                                        painter = painterResource(id = R.drawable.alarm_bell_tone),
                                                        contentDescription = "Alarm tone",
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(Modifier.width(5.dp))
                                                    Text(
                                                        config.time,
                                                        color = homeText,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        softWrap = false
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            Button(
                                onClick = { tab = "Calendar" },
                                modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = homeBlue),
                                shape = RoundedCornerShape(13.dp)
                            ) {
                                Text("+  ${dutyUi("+ Add / Assign Schedule", isFilipino)}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                "Configs" -> {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(dutyUi("Schedule Configs", isFilipino), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(dutyUi("Edit once to update every assigned date.", isFilipino), color = Muted, fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                editingId = -1
                                dialog = "config"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue)
                        ) { Text(dutyUi("+ Add", isFilipino)) }
                    }

                    Spacer(Modifier.height(10.dp))

                    Text(
                        dutyUi(
                            "Long-press a Config to select it, then tap another Config to move the selected one below it. Scroll normally if needed.",
                            isFilipino
                        ),
                        color = Muted,
                        fontSize = 12.sp
                    )
                    val haptic = LocalHapticFeedback.current
                    configs.forEachIndexed { itemIndex, c ->
                        val isSelected = selectedConfigId == c.id
                        var previousIndex by remember(c.id) { mutableIntStateOf(itemIndex) }
                        val placementOffset by animateDpAsState(
                            targetValue = ((previousIndex - itemIndex) * 88).dp,
                            animationSpec = tween(durationMillis = 220),
                            label = "config-reorder-${c.id}"
                        )
                        LaunchedEffect(itemIndex) { previousIndex = itemIndex }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                                .offset(y = placementOffset)
                                .graphicsLayer {
                                    val selectedScale = if (isSelected) 1.015f else 1f
                                    scaleX = selectedScale
                                    scaleY = selectedScale
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) surfaceColor.copy(alpha = 0.96f) else surfaceColor
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp, if (isSelected) Blue else if (darkTheme) Color(0xFF454545) else Color(0xFFDCE2EA)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // The entire left content is the invisible drag handle.
                                // Hold here with one finger; use the other finger anywhere on the screen to scroll.
                                Row(
                                    Modifier.weight(1f)
                                        .pointerInput(c.id, selectedConfigId, configs.map { it.id }) {
                                            detectTapGestures(
                                                onLongPress = {
                                                    selectedConfigId = c.id
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                },
                                                onTap = {
                                                    val selectedId = selectedConfigId
                                                    if (selectedId != null && selectedId != c.id) {
                                                        val from = configs.indexOfFirst { it.id == selectedId }
                                                        val target = configs.indexOfFirst { it.id == c.id }
                                                        if (from >= 0 && target >= 0) {
                                                            val insertAt = target - if (from < target) 1 else 0
                                                            moveConfig(from, (insertAt + 1).coerceIn(0, configs.lastIndex))
                                                            selectedConfigId = null
                                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                        }
                                                    } else if (selectedId == c.id) {
                                                        selectedConfigId = null
                                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    }
                                                }
                                            )
                                        },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.width(8.dp).height(54.dp)
                                            .background(ScheduleTexts[c.color.coerceIn(0, 5)], RoundedCornerShape(8.dp))
                                    )
                                    Spacer(Modifier.width(11.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                                        val configToneTitle = try {
                                            val toneUri = c.toneUri?.let { Uri.parse(it) }
                                                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                                            RingtoneManager.getRingtone(context, toneUri)?.getTitle(context)
                                                ?: dutyUi("Default phone alarm tone", isFilipino)
                                        } catch (_: Exception) {
                                            dutyUi("Default phone alarm tone", isFilipino)
                                        }
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Image(
                                                painter = painterResource(id = R.drawable.alarm_bell_tone),
                                                contentDescription = dutyUi("Alarm tone", isFilipino),
                                                modifier = Modifier.size(17.dp)
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                configToneTitle,
                                                color = Muted,
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(Modifier.width(7.dp))
                                            Text(
                                                if (c.time.isBlank()) dutyUi("No alarm", isFilipino) else c.time,
                                                color = Muted,
                                                fontSize = 12.sp,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                Button(
                                    onClick = { editingId = c.id; dialog = "config" },
                                    contentPadding = PaddingValues(horizontal = 13.dp, vertical = 7.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7629C9)),
                                    shape = RoundedCornerShape(10.dp)
                                ) { Text(dutyUi("Edit", isFilipino), fontSize = 13.sp) }
                                Spacer(Modifier.width(6.dp))
                                Button(
                                    onClick = { editingId = c.id; dialog = "delete" },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 7.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93636)),
                                    shape = RoundedCornerShape(10.dp)
                                ) { Text(dutyUi("Delete", isFilipino), fontSize = 13.sp) }
                            }
                        }
                    }
                    Text(
                        "Editing a Config updates all dates assigned to it. Deleting removes it everywhere.",
                        color = Muted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }

                else -> {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(dutyUi("Calendar", isFilipino), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text(dutyUi("Tap a date to manage schedules.", isFilipino), color = Muted, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { dialog = "entry" },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue),
                            shape = RoundedCornerShape(11.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 9.dp)
                        ) { Text(dutyUi("+ Add Entry", isFilipino), fontWeight = FontWeight.Bold) }
                    }

                    Spacer(Modifier.height(12.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = surfaceColor),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (darkTheme) Color(0xFF454545) else Color(0xFFDCE2EA))
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    SimpleDateFormat("MMMM yyyy", if (isFilipino) Locale("fil", "PH") else Locale.US)
                                        .format(Calendar.getInstance().apply { set(year, month, 1) }.time),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = if (darkTheme) Color.White else Ink,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = {
                                    month--
                                    if (month < 0) { month = 11; year-- }
                                }) { Text("‹", fontSize = 25.sp, color = if (darkTheme) Color.White else Muted) }
                                TextButton(onClick = {
                                    month++
                                    if (month > 11) { month = 0; year++ }
                                }) { Text("›", fontSize = 25.sp, color = if (darkTheme) Color.White else Ink) }
                            }

                            Row(Modifier.fillMaxWidth()) {
                                listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").forEach {
                                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                        Text(dutyUi(it, isFilipino), color = if (darkTheme) Color.White else Muted, fontSize = 11.sp)
                                    }
                                }
                            }

                            val cal = Calendar.getInstance().apply {
                                set(year, month, 1)
                            }
                            val offset = cal.get(Calendar.DAY_OF_WEEK) - 1
                            val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                            val cells = (0 until offset).map { 0 } + (1..days).toList()

                            cells.chunked(7).forEach { week ->
                                Row(Modifier.fillMaxWidth()) {
                                    week.forEach { day ->
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .padding(2.dp)
                                                .height(76.dp)
                                                .background(
                                                    when {
                                                        day == 0 -> Color.Transparent
                                                        dateKey(year, month, day) == selectedDate ->
                                                            selectedCellColor
                                                        else -> softCellColor
                                                    },
                                                    RoundedCornerShape(9.dp)
                                                )
                                                .then(
                                                    if (day != 0) Modifier.border(
                                                        1.dp,
                                                        if (darkTheme) Color(0xFF555555) else Color(0xFFDCE2EA),
                                                        RoundedCornerShape(9.dp)
                                                    ) else Modifier
                                                )
                                                .clickable(enabled = day != 0) {
                                                    selectedDate = dateKey(year, month, day)
                                                },
                                            contentAlignment = Alignment.TopCenter
                                        ) {
                                            if (day != 0) {
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 2.dp, vertical = if (dateKey(year, month, day) == dateKey(Calendar.getInstance())) 19.dp else 2.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Top
                                                ) {
                                                    Text(
                                                        text = day.toString(),
                                                        color = if (darkTheme && dateKey(year, month, day) == selectedDate) Color.Black
                                                            else if (darkTheme) Color.White
                                                            else if (dateKey(year, month, day) == selectedDate) Blue else Ink,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp
                                                    )

                                                    val dayConfigs = assigned[dateKey(year, month, day)]
                                                        .orEmpty()
                                                        .mapNotNull { id -> config(id) }

                                                    dayConfigs.take(2).forEach { schedule ->
                                                        val scheduleBg = ScheduleBackgrounds[schedule.color.coerceIn(0, 5)]
                                                        val scheduleText = ScheduleTexts[schedule.color.coerceIn(0, 5)]
                                                        Text(
                                                            text = schedule.name,
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(top = 0.dp)
                                                                .background(scheduleBg, RoundedCornerShape(3.dp))
                                                                .padding(horizontal = 1.dp, vertical = 0.dp),
                                                            color = scheduleText,
                                                            fontSize = 6.sp,
                                                            lineHeight = 6.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            maxLines = 1,
                                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                                        )
                                                    }

                                                    if (dayConfigs.size > 2) {
                                                        Text(
                                                            text = "+${dayConfigs.size - 2} more",
                                                            modifier = Modifier.padding(top = 0.dp),
                                                            fontSize = 6.sp,
                                                            lineHeight = 6.sp,
                                                            color = Blue,
                                                            fontWeight = FontWeight.Bold,
                                                            maxLines = 1
                                                        )
                                                    }
                                                }
                                                if (dateKey(year, month, day) == dateKey(Calendar.getInstance())) {
                                                    TodayNeonFrame(Modifier.fillMaxSize())
                                                }
                                            }
                                        }
                                    }
                                    repeat(7 - week.size) {
                                        Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = surfaceColor),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (darkTheme) Color(0xFF454545) else Color(0xFFDCE2EA))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(dateLabel(selectedDate), fontWeight = FontWeight.Bold, color = if (darkTheme) Color.White else Ink)
                            Text(dutyUi("Assigned entries", isFilipino), color = Muted, fontSize = 12.sp)

                            val ids = assigned[selectedDate].orEmpty()

                            if (ids.isEmpty()) {
                                Text(dutyUi("No schedule assigned yet.", isFilipino), color = Muted, modifier = Modifier.padding(vertical = 12.dp))
                            }

                            ids.forEach { id ->
                                val c = config(id)
                                if (c != null) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 3.dp)
                                            .border(1.dp, if (darkTheme) Color(0xFF454545) else Color(0xFFDCE2EA), RoundedCornerShape(11.dp))
                                            .background(if (darkTheme) Color(0xFF050505) else Color.White, RoundedCornerShape(11.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            Modifier.width(7.dp).height(34.dp)
                                                .background(ScheduleTexts[c.color.coerceIn(0, 5)], RoundedCornerShape(8.dp))
                                        )
                                        Spacer(Modifier.width(9.dp))
                                        Text(c.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), color = Ink)
                                        Text(if (c.time.isBlank()) "—" else "🔔  ${c.time}", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        Spacer(Modifier.width(8.dp))
                                        Button(
                                            onClick = {
                                                DutyAlarmScheduler.cancel(context, selectedDate, id)
                                                assigned[selectedDate] = ids - id
                                                rescheduleAll()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93636)),
                                            shape = RoundedCornerShape(9.dp),
                                            contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp)
                                        ) { Text(dutyUi("Remove", isFilipino), fontSize = 12.sp) }
                                    }
                                }
                            }

                            Button(
                                onClick = { dialog = "assign" },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Blue)
                            ) { Text(dutyUi("+ Assign Configs", isFilipino)) }
                        }
                    }
                }
            }
        }
    }

    if (dialog == "config" || dialog == "entry") {
        val old = configs.find { it.id == editingId }
        var name by remember(dialog, editingId) { mutableStateOf(old?.name ?: "") }
        var time by remember(dialog, editingId) { mutableStateOf(old?.time ?: "") }
        var scheduleColor by remember(dialog, editingId) { mutableIntStateOf(old?.color ?: 0) }
        var scheduleToneUri by remember(dialog, editingId) { mutableStateOf(old?.toneUri) }

        val ringtonePicker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val pickedUri = result.data
                    ?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                scheduleToneUri = pickedUri?.toString()
            }
        }

        AlertDialog(
            onDismissRequest = {
                stopTonePreview()
                dialog = ""
            },
            title = { Text(dutyUi(if (dialog == "entry") "Add Entry" else if (old == null) "Add Schedule" else "Edit Schedule", isFilipino)) },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(dutyUi("Schedule name", isFilipino)) },
                        placeholder = { Text(dutyUi("e.g. Morning Duty", isFilipino)) },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(dutyUi("Schedule color", isFilipino), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ScheduleColorNames.forEachIndexed { index, colorName ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (scheduleColor == index) ScheduleBackgrounds[index] else Color(0xFFF5F7FB),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { scheduleColor = index }
                                    .padding(vertical = 7.dp, horizontal = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .background(ScheduleTexts[index], RoundedCornerShape(50))
                                )
                                Text(
                                    colorName,
                                    color = ScheduleTexts[index],
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                                RadioButton(
                                    selected = scheduleColor == index,
                                    onClick = { scheduleColor = index },
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(dutyUi("Alarm tone", isFilipino), fontWeight = FontWeight.Bold)
                    Text(
                        if (scheduleToneUri == null) "Default phone alarm tone"
                        else try {
                            RingtoneManager.getRingtone(context, Uri.parse(scheduleToneUri))
                                ?.getTitle(context) ?: "Selected ringtone"
                        } catch (_: Exception) {
                            "Selected ringtone"
                        },
                        color = Muted,
                        fontSize = 12.sp,
                        maxLines = 2
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                stopTonePreview()
                                val pickerIntent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select duty alarm tone")
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                    putExtra(
                                        RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                                        scheduleToneUri?.let { Uri.parse(it) }
                                            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                                    )
                                }
                                ringtonePicker.launch(pickerIntent)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(dutyUi("Choose tone", isFilipino)) }
                        OutlinedButton(
                            onClick = { previewTone(scheduleToneUri) },
                            modifier = Modifier.weight(1f)
                        ) { Text(dutyUi("▶ Preview", isFilipino)) }
                    }
                    TextButton(
                        onClick = {
                            stopTonePreview()
                            scheduleToneUri = null
                        }
                    ) { Text(dutyUi("Use default tone", isFilipino)) }

                    Spacer(Modifier.height(10.dp))
                    Text(dutyUi("Alarm time (optional)", isFilipino), fontWeight = FontWeight.Bold)

                    WheelTimePicker(
                        initialTime = time,
                        onTimeChange = { time = it }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        if (old != null) {
                            val index = configs.indexOfFirst { it.id == old.id }
                            if (index >= 0) configs[index] = old.copy(name = name.trim(), time = time.trim(), color = scheduleColor, toneUri = scheduleToneUri)
                        } else {
                            val id = nextId++
                            configs.add(DutyConfig(id, name.trim(), time.trim(), scheduleColor, scheduleToneUri))
                            if (dialog == "entry") {
                                assigned[selectedDate] = assigned[selectedDate].orEmpty() + id
                            }
                        }
                        stopTonePreview()
                        rescheduleAll()
                        dialog = ""
                    }
                }) { Text(dutyUi("Save", isFilipino)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    stopTonePreview()
                    dialog = ""
                }) { Text(dutyUi("Cancel", isFilipino)) }
            }
        )
    }

    if (dialog == "delete") {
        val c = configs.find { it.id == editingId }
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(dutyUi("Delete Schedule?", isFilipino)) },
            text = { Text(if (isFilipino) "${c?.name} ay aalisin sa Mga Schedule at sa lahat ng petsang naka-assign sa kalendaryo." else "${c?.name} will be removed from Configs and all assigned calendar dates.") },
            confirmButton = {
                TextButton(onClick = {
                    removeConfig(editingId)
                    dialog = ""
                }) { Text(dutyUi("Delete", isFilipino), color = Color.Red) }
            },
            dismissButton = {
                TextButton(onClick = { dialog = "" }) { Text(dutyUi("Cancel", isFilipino)) }
            }
        )
    }

    if (dialog == "assign") {
        val selectedIds = remember(selectedDate) {
            mutableStateListOf<Int>().apply {
                addAll(assigned[selectedDate].orEmpty())
            }
        }

        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(dutyUi("Assign Schedules", isFilipino)) },
            text = {
                Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                    Text(dateLabel(selectedDate), color = Muted, fontSize = 12.sp)
                    configs.forEach { c ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = c.id in selectedIds,
                                onCheckedChange = {
                                    if (it) selectedIds.add(c.id)
                                    else selectedIds.remove(c.id)
                                }
                            )
                            Column {
                                Text(c.name)
                                Text(c.time.ifBlank { dutyUi("No alarm", isFilipino) }, color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val previousIds = assigned[selectedDate].orEmpty()
                    (previousIds - selectedIds.toSet()).forEach { removedId ->
                        DutyAlarmScheduler.cancel(context, selectedDate, removedId)
                    }
                    assigned[selectedDate] = selectedIds.toSet()
                    rescheduleAll()
                    dialog = ""
                }) { Text(dutyUi("Save Assignment", isFilipino)) }
            },
            dismissButton = {
                TextButton(onClick = { dialog = "" }) { Text(dutyUi("Cancel", isFilipino)) }
            }
        )
    }
    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text(dutyUi("Settings", isFilipino)) },
            text = {
                Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(dutyUi("Help & how to use the app", isFilipino), fontWeight = FontWeight.Bold)
                    Text(dutyUi("Step-by-step guide for Configs, Calendar, alarms, and permissions.", isFilipino), color = Muted, fontSize = 13.sp)
                    OutlinedButton(onClick = { showHelpDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(dutyUi("Open Help / User Guide", isFilipino))
                    }
                    HorizontalDivider()
                    Text(if (isFilipino) "Language / Wika" else "Language", fontWeight = FontWeight.Bold)
                    Text(
                        if (isFilipino) "Piliin ang wikang gagamitin sa mga gabay at paliwanag ng app." else "Choose the language used in app guides and explanations.",
                        color = Muted,
                        fontSize = 13.sp
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = appLanguage == "en",
                            onClick = {
                                appLanguage = "en"
                                themePrefs.edit().putString("app_language", "en").apply()
                            },
                            label = { Text(dutyUi("English", isFilipino)) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = appLanguage == "fil",
                            onClick = {
                                appLanguage = "fil"
                                themePrefs.edit().putString("app_language", "fil").apply()
                            },
                            label = { Text(dutyUi("Filipino", isFilipino)) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    HorizontalDivider()
                    Text(if (isFilipino) "Appearance / Hitsura" else "Appearance", fontWeight = FontWeight.Bold)
                    Text(dutyUi("Choose your preferred app theme.", isFilipino), color = Muted, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = !darkTheme,
                            onClick = {
                                darkTheme = false
                                themePrefs.edit().putBoolean("dark_theme", false).apply()
                                DutyCalendarWidgetProvider.refreshAll(context)
                            },
                            label = { Text(dutyUi("Light", isFilipino)) },
                            leadingIcon = {
                                Text(dutyUi("☀", isFilipino), color = if (!darkTheme) Blue else Muted)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = darkTheme,
                            onClick = {
                                darkTheme = true
                                themePrefs.edit().putBoolean("dark_theme", true).apply()
                                DutyCalendarWidgetProvider.refreshAll(context)
                            },
                            label = { Text(dutyUi("Dark", isFilipino)) },
                            leadingIcon = {
                                Text(dutyUi("☾", isFilipino), color = if (darkTheme) Blue else Muted)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    HorizontalDivider()
                    Text(dutyUi("Alarm permissions", isFilipino), fontWeight = FontWeight.Bold)
                    Text(dutyUi("Enable these settings so alarms can ring on time and show the Snooze/Dismiss screen.", isFilipino), color = Muted, fontSize = 13.sp)

                    val alarmManager = context.getSystemService(AlarmManager::class.java)
                    val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
                    val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
                        context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                    val fullScreenAllowed = Build.VERSION.SDK_INT < 34 ||
                        context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
                    val batteryManager = context.getSystemService(PowerManager::class.java)
                    val batteryUnrestricted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                        batteryManager.isIgnoringBatteryOptimizations(context.packageName)

                    @Composable
                    fun PermissionLine(label: String, allowed: Boolean, help: String, onOpen: () -> Unit) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(dutyUi(label, isFilipino), fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                Text(if (allowed) dutyUi("Allowed", isFilipino) else dutyUi("Needs attention", isFilipino), color = if (allowed) Color(0xFF23834A) else Color(0xFFC05A20), fontSize = 12.sp)
                            }
                            TextButton(onClick = { permissionHelpTopic = help }) { Text(dutyUi("ⓘ", isFilipino)) }
                            TextButton(onClick = onOpen) { Text(if (allowed) dutyUi("View", isFilipino) else dutyUi("Enable", isFilipino)) }
                        }
                    }

                    PermissionLine("Alarms & reminders", exactAllowed,
                        if (isFilipino) "Exact alarms: buksan ang Alarms & reminders / Schedule exact alarms para sa Duty Calendar at i-enable ang Allow setting. Kailangan ito para tumunog ang alarm sa eksaktong oras." else "Exact alarms: open Alarms & reminders / Schedule exact alarms for Duty Calendar and enable Allow. This lets alarms ring at the scheduled time.") {
                        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:" + context.packageName))
                        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + context.packageName))
                        context.startActivity(intent)
                    }
                    PermissionLine("Notifications", notificationsAllowed,
                        if (isFilipino) "Notifications: buksan ang App notifications para sa Duty Calendar at i-enable ang Allow notifications. Kailangan ito para makita ang alarm notification at controls." else "Notifications: open App notifications for Duty Calendar and enable Allow notifications. This is needed to show alarm notifications and controls.") {
                        context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                    }
                    PermissionLine("Full-screen alarm", fullScreenAllowed,
                        if (isFilipino) "Full-screen alarm: sa Special app access / Full-screen notifications, piliin ang Duty Calendar at payagan ang full-screen display kung available. Nakakatulong ito para lumabas ang alarm screen kahit naka-lock ang phone." else "Full-screen alarm: under Special app access / Full-screen notifications, select Duty Calendar and allow full-screen display if available. This helps show the alarm screen over the lock screen.") {
                        val intent = if (Build.VERSION.SDK_INT >= 34)
                            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).setData(Uri.parse("package:" + context.packageName))
                        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + context.packageName))
                        context.startActivity(intent)
                    }
                    PermissionLine("Battery optimization exemption", batteryUnrestricted,
                        if (isFilipino) "Battery: buksan ang Battery optimization o App battery usage para sa Duty Calendar. Piliin ang Unrestricted / Don't optimize / Allow background activity kung available. Hindi nito mapipigilan ang system Force stop o sariling cleanup feature ng phone." else "Battery: open Battery optimization or App battery usage for Duty Calendar. Choose Unrestricted / Don't optimize / Allow background activity if available. This cannot override a true system Force stop or a phone's own cleanup feature.") {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !batteryUnrestricted) {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                        data = Uri.parse("package:" + context.packageName)
                                    }
                                )
                            } catch (_: Exception) {
                                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            }
                        } else {
                            context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }
                    }
                    HorizontalDivider()
                    Text(dutyUi("Phone-specific background protection", isFilipino), fontWeight = FontWeight.Bold)
                    Text(
                        if (isFilipino) "MAHALAGA: May ilang phone na naglilinis o nagfo-force-stop ng apps kapag ginamit ang Clear All / Cleaner. Kapag nangyari ito, maaaring hindi tumunog ang naka-schedule na alarm. Hanapin ang Duty Calendar sa listahan ng apps na hindi dapat linisin o i-restrict."
                        else "IMPORTANT: Some phones clean up or force-stop apps when Clear All / Cleaner is used. If this happens, scheduled alarms may not ring. Find Duty Calendar in the list of apps that should be protected from cleanup or restrictions.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                    Text(dutyUi("ASUS / ROG", isFilipino), fontWeight = FontWeight.SemiBold)
                    Text(if (isFilipino) "Buksan ang Mobile Manager o Phone Manager → Memory Cleaner / Super Clean. Alisin ang Duty Calendar sa apps na lilinisin o idagdag ito sa protected / whitelist list kung available. Tingnan din ang Auto-start at Battery settings." else "Open Mobile Manager or Phone Manager → Memory Cleaner / Super Clean. Exclude Duty Calendar from cleanup or add it to the protected / whitelist list if available. Also check Auto-start and Battery settings.", color = Muted, fontSize = 12.sp)
                    Text(dutyUi("Xiaomi / Redmi / POCO", isFilipino), fontWeight = FontWeight.SemiBold)
                    Text(if (isFilipino) "App info → Battery saver → No restrictions. Sa Security app / Cleaner o Recent Apps, gamitin ang Lock kung may option para hindi maisama sa cleanup." else "App info → Battery saver → No restrictions. In the Security app / Cleaner or Recent Apps, use Lock if available to keep the app out of cleanup.", color = Muted, fontSize = 12.sp)
                    Text(dutyUi("Huawei / Honor", isFilipino), fontWeight = FontWeight.SemiBold)
                    Text(if (isFilipino) "Battery / App launch → piliin ang Duty Calendar, i-manage manually, at payagan ang Auto-launch, Secondary launch, at Run in background kung available." else "Battery / App launch → select Duty Calendar, manage it manually, and allow Auto-launch, Secondary launch, and Run in background if available.", color = Muted, fontSize = 12.sp)
                    Text(dutyUi("OPPO / realme / OnePlus", isFilipino), fontWeight = FontWeight.SemiBold)
                    Text(if (isFilipino) "Battery settings → App battery management / Background activity. Payagan ang background activity at auto-launch kung available; tingnan din ang Phone Manager cleanup list." else "Battery settings → App battery management / Background activity. Allow background activity and auto-launch if available; also check the Phone Manager cleanup list.", color = Muted, fontSize = 12.sp)
                    Text(dutyUi("Samsung Galaxy", isFilipino), fontWeight = FontWeight.SemiBold)
                    Text(if (isFilipino) "Battery → Background usage limits. Alisin ang Duty Calendar sa Sleeping / Deep sleeping apps at idagdag sa Never sleeping apps kung available." else "Battery → Background usage limits. Remove Duty Calendar from Sleeping / Deep sleeping apps and add it to Never sleeping apps if available.", color = Muted, fontSize = 12.sp)
                    Text(dutyUi("Menu names vary by phone model and Android version. These settings help prevent automatic cleanup; no app can override a true system Force stop or a user-disabled alarm permission.", isFilipino), color = Muted, fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showSettings = false }) { Text(dutyUi("Done", isFilipino)) }
            }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text(if (isFilipino) "Duty Calendar — Gabay sa Paggamit" else "Duty Calendar — User Guide") },
            text = {
                Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (isFilipino) {
                        Text(dutyUi("1. CONFIGS", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Pumunta sa Configs at pindutin ang Add Config para gumawa ng schedule. Ilagay ang pangalan, oras ng alarm (12-hour AM/PM), kulay, at ringtone. Maaari mong i-edit ang config; maa-update ang mga petsang naka-assign dito. Kapag dinelete, aalisin din ang assignment nito sa calendar.", isFilipino))
                        Text(dutyUi("Ayusin ang pagkakasunod-sunod", isFilipino), fontWeight = FontWeight.SemiBold)
                        Text(dutyUi("I-long-press ang Config para piliin ito; may haptic feedback. Mag-scroll sa target at i-tap ang ibang Config para mailipat ang napili sa ilalim nito. Awtomatikong mase-save ang bagong order at hindi maaapektuhan ang mga date assignment.", isFilipino))
                        Text(dutyUi("2. CALENDAR", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Pumili ng petsa sa Calendar. Pindutin ang Assign Configs para pumili ng isa o maraming schedule. Lalabas ang mga pangalan sa date cell. Buksan muli ang petsa kung gusto mong baguhin ang assignments.", isFilipino))
                        Text(dutyUi("3. ALARMS", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Bawat naka-assign na config na may alarm time ay magse-set ng alarm. Maaari kang pumili at mag-preview ng ringtone sa config. Sa alarm screen, ang Snooze ay magdadagdag ng 10 minuto; ang Dismiss ay titigil lang sa kasalukuyang alarm at hindi magde-delete ng schedule.", isFilipino))
                        Text(dutyUi("4. PERMISSIONS", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Sa Gear / Settings, tingnan ang status ng bawat permission. Pindutin ang ⓘ para sa paliwanag, o Enable / View para buksan ang kaukulang Android settings. Pagkatapos baguhin ang permission, bumalik sa app at tingnan muli ang status.", isFilipino))
                        Text(dutyUi("5. PHONE BACKGROUND PROTECTION", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("May ilang phone brand na may sariling cleaner o Super Clean feature na maaaring mag-force-stop ng apps. Sundin ang gabay para sa brand sa Gear / Settings at alisin ang Duty Calendar sa cleanup list kung may ganitong option. Maaaring mag-iba ang pangalan ng menu depende sa model at Android version.", isFilipino))
                    } else {
                        Text(dutyUi("1. CONFIGS", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Open Configs and tap Add Config to create a schedule. Enter its name, alarm time (12-hour AM/PM), color, and ringtone. Editing a config updates the dates assigned to it. Deleting a config also removes its calendar assignments.", isFilipino))
                        Text(dutyUi("Reorder schedules", isFilipino), fontWeight = FontWeight.SemiBold)
                        Text(dutyUi("Long-press a Config to select it; haptic feedback confirms selection. Scroll to the destination and tap another Config to move the selected one below it. The new order is saved automatically and does not change date assignments.", isFilipino))
                        Text(dutyUi("2. CALENDAR", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Select a date in Calendar. Tap Assign Configs to choose one or more schedules. Their names appear in the date cell. Open the date again whenever you need to change its assignments.", isFilipino))
                        Text(dutyUi("3. ALARMS", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Each assigned config with an alarm time schedules an alarm. You can choose and preview a ringtone in the config. On the alarm screen, Snooze adds 10 minutes; Dismiss stops only the current alarm and does not delete the schedule.", isFilipino))
                        Text(dutyUi("4. PERMISSIONS", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("In Gear / Settings, check the status of each permission. Tap ⓘ for an explanation, or Enable / View to open the relevant Android settings. After changing a permission, return to the app and check its status again.", isFilipino))
                        Text(dutyUi("5. PHONE BACKGROUND PROTECTION", isFilipino), fontWeight = FontWeight.Bold)
                        Text(dutyUi("Some phone brands have their own cleaner or Super Clean feature that may force-stop apps. Follow the brand-specific guide in Gear / Settings and remove Duty Calendar from the cleanup list if that option is available. Menu names may vary by model and Android version.", isFilipino))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHelpDialog = false }) { Text(if (isFilipino) "Isara" else "Close") } }
        )
    }

    if (permissionHelpTopic.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { permissionHelpTopic = "" },
            title = { Text(dutyUi("Permission help", isFilipino)) },
            text = { Text(permissionHelpTopic) },
            confirmButton = { TextButton(onClick = { permissionHelpTopic = "" }) { Text(dutyUi("Got it", isFilipino)) } }
        )
    }

    if (showExactAlarmHelp && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        AlertDialog(
            onDismissRequest = { showExactAlarmHelp = false },
            title = { Text(dutyUi("Allow exact alarms", isFilipino)) },
            text = {
                Text(
                    if (isFilipino)
                        "Kailangan ng Duty Calendar ang Alarms & reminders permission para tumunog sa nakatakdang oras. Payagan ang Duty Calendar sa Settings. Hindi nito babaguhin ang Silent/Vibrate mode."
                    else
                        "Duty Calendar needs the Alarms & reminders permission to ring at the scheduled time. Allow Duty Calendar in Settings. This will not change your Silent/Vibrate mode."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showExactAlarmHelp = false
                    try {
                        context.startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                data = Uri.parse("package:" + context.packageName)
                            }
                        )
                    } catch (_: Exception) {
                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:" + context.packageName)
                        })
                    }
                }) { Text(dutyUi("Open Settings", isFilipino)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    val manager = context.getSystemService(AlarmManager::class.java)
                    if (manager.canScheduleExactAlarms()) {
                        showExactAlarmHelp = false
                        rescheduleAll()
                    } else {
                        showExactAlarmHelp = true
                    }
                }) { Text(dutyUi("Check again", isFilipino)) }
            }
        )
    }
}

@Composable
fun InfoCard(
    title: String,
    value: String,
    detail: String,
    modifier: Modifier = Modifier,
    surfaceColor: Color = Color.White,
    inkColor: Color = Ink,
    mutedColor: Color = Muted
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = surfaceColor)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = mutedColor, fontSize = 10.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = inkColor, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(detail, fontSize = 11.sp, color = mutedColor, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

fun formatCountdown(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val days = totalSeconds / 86_400L
    val hours = (totalSeconds % 86_400L) / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L

    return String.format(Locale.US, "%02d:%02d:%02d:%02d", days, hours, minutes, seconds)
}

fun dateKey(calendar: Calendar): String {
    return dateKey(
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )
}

fun dateKey(year: Int, month: Int, day: Int): String {
    return String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
}

@Composable
fun WheelTimePicker(
    initialTime: String,
    onTimeChange: (String) -> Unit
) {
    // AndroidView's factory is created once. Keep its callback current without
    // rebuilding the native NumberPicker (which can otherwise drop text focus).
    val currentOnTimeChange by rememberUpdatedState(onTimeChange)
    val parsed = remember(initialTime) {
        try {
            val parts = initialTime.trim().split(" ")
            val hm = parts[0].split(":")
            Triple(
                hm[0].toInt(),
                hm[1].toInt(),
                parts.getOrElse(1) { "AM" }
            )
        } catch (_: Exception) {
            Triple(5, 0, "AM")
        }
    }

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
        factory = { context ->

            val layout = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER
            }

            val hour = NumberPicker(context).apply {
                minValue = 1
                maxValue = 12
                displayedValues = (1..12).map {
                    String.format(Locale.US, "%02d", it)
                }.toTypedArray()
                value = parsed.first.coerceIn(1, 12)
                wrapSelectorWheel = true
                descendantFocusability = NumberPicker.FOCUS_BEFORE_DESCENDANTS
                for (index in 0 until childCount) {
                    (getChildAt(index) as? android.widget.EditText)?.inputType =
                        android.text.InputType.TYPE_CLASS_NUMBER
                }
            }

            val minute = NumberPicker(context).apply {
                minValue = 0
                maxValue = 59
                displayedValues = (0..59).map {
                    String.format(Locale.US, "%02d", it)
                }.toTypedArray()
                value = parsed.second.coerceIn(0, 59)
                wrapSelectorWheel = true
                descendantFocusability = NumberPicker.FOCUS_BEFORE_DESCENDANTS
                for (index in 0 until childCount) {
                    (getChildAt(index) as? android.widget.EditText)?.inputType =
                        android.text.InputType.TYPE_CLASS_NUMBER
                }
            }

            val ampm = NumberPicker(context).apply {
                minValue = 0
                maxValue = 1
                displayedValues = arrayOf("AM", "PM")
                value = if (parsed.third.uppercase() == "PM") 1 else 0
                wrapSelectorWheel = false
                descendantFocusability = NumberPicker.FOCUS_BLOCK_DESCENDANTS
            }

            fun publishTime() {
                val period = if (ampm.value == 0) "AM" else "PM"
                currentOnTimeChange(
                    String.format(
                        Locale.US,
                        "%02d:%02d %s",
                        hour.value,
                        minute.value,
                        period
                    )
                )
            }

            val listener =
                NumberPicker.OnValueChangeListener { _, _, _ ->
                    publishTime()
                }

            hour.setOnValueChangedListener(listener)
            minute.setOnValueChangedListener(listener)
            ampm.setOnValueChangedListener(listener)

            val params = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT,
                1f
            )

            layout.addView(hour, params)
            layout.addView(minute, params)
            layout.addView(ampm, params)

            layout
        },
        update = {}
    )
}
