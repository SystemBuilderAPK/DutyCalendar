package com.example.dutycalendar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class DutyAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val saved = DutyDataStore.load(context)
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                context.getSystemService(android.app.AlarmManager::class.java).canScheduleExactAlarms()
            ) {
                saved.assigned.forEach { (date, ids) ->
                    ids.forEach { id ->
                        val config = saved.configs.firstOrNull { it.id == id } ?: return@forEach
                        if (config.time.isNotBlank()) {
                            DutyAlarmScheduler.schedule(context, date, config)
                        }
                    }
                }
            }
            return
        }

        if (intent.action != ACTION_DUTY_ALARM) return

        val serviceIntent = Intent(context, AlarmSoundService::class.java).apply {
            action = AlarmSoundService.ACTION_START
            putExtra(AlarmSoundService.EXTRA_TONE_URI, intent.getStringExtra(AlarmSoundService.EXTRA_TONE_URI))
            putExtra(AlarmSoundService.EXTRA_ALARM_TITLE, intent.getStringExtra(AlarmSoundService.EXTRA_ALARM_TITLE) ?: "Duty Alarm")
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            // Android may block service startup under exceptional system conditions.
        }
    }

    companion object {
        const val ACTION_DUTY_ALARM = "com.example.dutycalendar.action.DUTY_ALARM"
    }
}
