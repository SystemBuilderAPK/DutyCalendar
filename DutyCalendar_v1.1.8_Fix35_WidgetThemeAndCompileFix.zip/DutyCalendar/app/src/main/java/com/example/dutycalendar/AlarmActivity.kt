package com.example.dutycalendar

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlarmActivity : Activity() {

    private var alarmTitle: String = "Duty Alarm"
    private var toneString: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        readAlarmIntent(intent)
        showAlarmControls()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readAlarmIntent(intent)
        showAlarmControls()
    }

    private fun readAlarmIntent(intent: Intent?) {
        alarmTitle = intent?.getStringExtra(AlarmSoundService.EXTRA_ALARM_TITLE) ?: "Duty Alarm"
        toneString = intent?.getStringExtra(AlarmSoundService.EXTRA_TONE_URI)
    }

    private fun showAlarmControls() {
        val prefs = getSharedPreferences("duty_alarm_settings", MODE_PRIVATE)
        val filipino = prefs.getString("app_language", "en") == "fil"
        val dark = prefs.getBoolean("dark_theme", false)

        val bgTop = if (dark) android.graphics.Color.rgb(10, 17, 29) else android.graphics.Color.rgb(250, 249, 244)
        val bgBottom = if (dark) android.graphics.Color.rgb(18, 29, 45) else android.graphics.Color.rgb(226, 240, 250)
        val primary = if (dark) android.graphics.Color.rgb(245, 247, 252) else android.graphics.Color.rgb(25, 35, 51)
        val secondary = if (dark) android.graphics.Color.rgb(171, 184, 204) else android.graphics.Color.rgb(83, 101, 126)
        val cardFill = if (dark) android.graphics.Color.rgb(24, 37, 57) else android.graphics.Color.rgb(255, 255, 255)
        val gold = android.graphics.Color.rgb(205, 174, 111)
        val coral = android.graphics.Color.rgb(238, 126, 111)
        val blue = android.graphics.Color.rgb(119, 174, 211)

        fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
        fun rounded(fill: Int, stroke: Int, strokeWidth: Int = 1, radius: Float = 26f) =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(fill)
                cornerRadius = dp(radius).toFloat()
                setStroke(dp(strokeWidth.toFloat()), stroke)
            }
        fun label(
            value: String, size: Float, color: Int, bold: Boolean = false,
            gravity: Int = Gravity.CENTER
        ) = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            this.gravity = gravity
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            includeFontPadding = true
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22f), dp(12f), dp(22f), dp(22f))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(bgTop, bgBottom)
            )
        }

        val header = label("▣  Duty Alarm", 25f, primary, true)
        root.addView(header, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(58f)
        ))

        // Flexible center area keeps the time and schedule card visually centered.
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        root.addView(center, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val timeFormat = java.text.SimpleDateFormat("h:mm", java.util.Locale.getDefault())
        val amPmFormat = java.text.SimpleDateFormat("a", java.util.Locale.getDefault())
        val now = java.util.Date()
        val time = label("${timeFormat.format(now)} ${amPmFormat.format(now)}", 62f, primary, true)
        center.addView(time, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(34f) })

        val scheduleCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24f), dp(18f), dp(24f), dp(18f))
            background = rounded(cardFill, gold, 2, 24f)
            elevation = dp(12f).toFloat()
        }
        val name = label("ϟ  $alarmTitle", 27f, primary, true)
        val ringing = label(if (filipino) "TUMUTUNOG NGAYON" else "NOW RINGING", 17f, secondary, true)
        val dateText = java.text.SimpleDateFormat("EEE, MMM d", java.util.Locale.getDefault()).format(now)
        val date = label("▦  $dateText", 18f, primary, false)
        scheduleCard.addView(name)
        scheduleCard.addView(ringing, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8f) })
        scheduleCard.addView(date, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8f) })
        center.addView(scheduleCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            leftMargin = dp(28f)
            rightMargin = dp(28f)
        })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            weightSum = 10f
        }

        // Swipe-to-dismiss track with a movable thumb.
        val dismissTrack = android.widget.FrameLayout(this).apply {
            background = rounded(
                if (dark) android.graphics.Color.rgb(54, 39, 48) else android.graphics.Color.rgb(255, 220, 205),
                if (dark) android.graphics.Color.rgb(126, 91, 75) else android.graphics.Color.rgb(225, 160, 128),
                2, 48f
            )
            elevation = dp(5f).toFloat()
        }
        val dismissText = label(
            if (filipino) "I-SWIPE PARA I-DISMISS" else "SWIPE TO DISMISS",
            15f, if (dark) android.graphics.Color.rgb(238, 224, 215) else android.graphics.Color.rgb(92, 65, 59), true
        )
        dismissTrack.addView(dismissText, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT
        ).apply {
            leftMargin = dp(54f)
            rightMargin = dp(8f)
        })
        val thumb = label("✓", 29f, android.graphics.Color.WHITE, true).apply {
            background = rounded(
                if (dark) android.graphics.Color.rgb(132, 111, 72) else android.graphics.Color.rgb(211, 174, 105),
                gold, 2, 100f
            )
            elevation = dp(5f).toFloat()
        }
        val thumbSize = dp(62f)
        val thumbParams = android.widget.FrameLayout.LayoutParams(
            thumbSize, thumbSize, Gravity.CENTER_VERTICAL or Gravity.LEFT
        ).apply { leftMargin = dp(4f) }
        dismissTrack.addView(thumb, thumbParams)

        var downX = 0f
        var startTranslation = 0f
        dismissTrack.setOnTouchListener { _, event ->
            val maxTravel = (dismissTrack.width - thumb.width - dp(8f)).coerceAtLeast(0).toFloat()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    startTranslation = thumb.translationX
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val next = (startTranslation + event.rawX - downX).coerceIn(0f, maxTravel)
                    thumb.translationX = next
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (thumb.translationX >= maxTravel * 0.72f && maxTravel > 0f) {
                        sendServiceAction(AlarmSoundService.ACTION_STOP)
                        finish()
                    } else {
                        thumb.animate().translationX(0f).setDuration(180).start()
                        if (event.actionMasked == MotionEvent.ACTION_UP) {
                            dismissTrack.performHapticFeedback(android.view.HapticFeedbackConstants.REJECT)
                        }
                    }
                    true
                }
                else -> true
            }
        }

        val snoozeButton = label(
            if (filipino) "Zz  I-SNOOZE\n(+10 minuto)" else "Zz  SNOOZE\n(+10 mins)",
            16f, if (dark) android.graphics.Color.rgb(226, 236, 250) else android.graphics.Color.rgb(43, 66, 96), true
        ).apply {
            background = rounded(
                if (dark) android.graphics.Color.rgb(35, 53, 76) else android.graphics.Color.rgb(235, 246, 252),
                blue, 2, 48f
            )
            elevation = dp(5f).toFloat()
            setPadding(dp(6f), dp(8f), dp(6f), dp(8f))
            setOnClickListener {
                sendServiceAction(AlarmSoundService.ACTION_SNOOZE)
                finish()
            }
        }

        controls.addView(dismissTrack, LinearLayout.LayoutParams(
            0, dp(76f), 6.2f
        ).apply { rightMargin = dp(10f) })
        controls.addView(snoozeButton, LinearLayout.LayoutParams(
            0, dp(76f), 3.8f
        ))
        root.addView(controls, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(82f)
        ))

        window.statusBarColor = bgTop
        window.navigationBarColor = bgBottom
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility =
                if (!dark) android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                    android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                else 0
        }
        setContentView(root)
    }

    private fun sendServiceAction(action: String) {
        val serviceIntent = Intent(this, AlarmSoundService::class.java).apply {
            this.action = action
            putExtra(AlarmSoundService.EXTRA_ALARM_TITLE, alarmTitle)
            putExtra(AlarmSoundService.EXTRA_TONE_URI, toneString)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
