package com.example.dutycalendar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class DutyCalendarWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_MONTH -> {
                val delta = intent.getIntExtra(EXTRA_DELTA, 0)
                val cal = Calendar.getInstance().apply {
                    set(prefs.getInt(KEY_YEAR, get(Calendar.YEAR)), prefs.getInt(KEY_MONTH, get(Calendar.MONTH)), 1)
                    add(Calendar.MONTH, delta)
                }
                prefs.edit().putInt(KEY_YEAR, cal.get(Calendar.YEAR)).putInt(KEY_MONTH, cal.get(Calendar.MONTH)).apply()
            }
            ACTION_DATE -> prefs.edit().putString(KEY_DATE, intent.getStringExtra(EXTRA_DATE)).apply()
            ACTION_TOGGLE_CONFIG -> {
                val date = prefs.getString(KEY_DATE, todayKey()) ?: todayKey()
                val id = intent.getIntExtra(EXTRA_CONFIG_ID, -1)
                if (id >= 0) {
                    val data = DutyDataStore.load(context)
                    val set = data.assigned[date].orEmpty().toMutableSet()
                    if (!set.add(id)) set.remove(id)
                    val updated = data.assigned.toMutableMap().apply {
                        if (set.isEmpty()) remove(date) else put(date, set)
                    }
                    DutyAlarmScheduler.cancelAll(context, data.assigned)
                    DutyDataStore.save(context, data.configs, updated, data.nextId, refreshWidgets = false)
                    updated.forEach { (dateKey, ids) ->
                        ids.forEach { configId -> data.configs.firstOrNull { it.id == configId }?.let { config ->
                            DutyAlarmScheduler.schedule(context, dateKey, config)
                        } }
                    }
                }
            }
        }
        refreshAll(context)
    }

    companion object {
        const val ACTION_MONTH = "com.example.dutycalendar.widget.MONTH"
        const val ACTION_DATE = "com.example.dutycalendar.widget.DATE"
        const val ACTION_TOGGLE_CONFIG = "com.example.dutycalendar.widget.TOGGLE_CONFIG"
        const val EXTRA_DELTA = "delta"
        const val EXTRA_DATE = "date"
        const val EXTRA_CONFIG_ID = "config_id"
        private const val PREFS = "duty_calendar_widget"
        private const val KEY_YEAR = "year"
        private const val KEY_MONTH = "month"
        private const val KEY_DATE = "selected_date"

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, DutyCalendarWidgetProvider::class.java))
            ids.forEach { updateWidget(context, manager, it) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val now = Calendar.getInstance()
            val year = prefs.getInt(KEY_YEAR, now.get(Calendar.YEAR))
            val month = prefs.getInt(KEY_MONTH, now.get(Calendar.MONTH))
            val selected = prefs.getString(KEY_DATE, todayKey()) ?: todayKey()
            val data = DutyDataStore.load(context)
            val darkTheme = context.getSharedPreferences("duty_alarm_settings", Context.MODE_PRIVATE)
                .getBoolean("dark_theme", false)
            val views = RemoteViews(context.packageName, R.layout.widget_duty_calendar)
            val pageBg = if (darkTheme) Color.BLACK else Color.rgb(243, 246, 251)
            val ink = if (darkTheme) Color.rgb(241, 245, 249) else Color.rgb(23, 32, 51)
            val muted = if (darkTheme) Color.rgb(176, 186, 200) else Color.rgb(102, 112, 133)
            val cellBg = if (darkTheme) Color.rgb(28, 28, 28) else Color.rgb(245, 247, 251)
            views.setInt(R.id.widget_root, "setBackgroundColor", pageBg)
            views.setTextColor(R.id.widget_month, ink)
            views.setTextColor(R.id.widget_prev, ink)
            views.setTextColor(R.id.widget_next, ink)
            views.setTextColor(R.id.widget_selected_title, ink)
            views.setTextColor(R.id.widget_hint, muted)
            views.setTextColor(R.id.widget_manage, if (darkTheme) Color.rgb(100, 181, 246) else Color.rgb(40, 102, 216))
            val monthCal = Calendar.getInstance().apply { set(year, month, 1) }
            views.setTextViewText(R.id.widget_month, SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(monthCal.time))
            views.setOnClickPendingIntent(R.id.widget_prev, actionPending(context, ACTION_MONTH, -1, "prev"))
            views.setOnClickPendingIntent(R.id.widget_next, actionPending(context, ACTION_MONTH, 1, "next"))
            views.setOnClickPendingIntent(R.id.widget_manage, PendingIntent.getActivity(context, 8001, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            views.removeAllViews(R.id.widget_weekdays)
            listOf("S", "M", "T", "W", "T", "F", "S").forEach { label ->
                val cell = RemoteViews(context.packageName, R.layout.widget_weekday_cell)
                cell.setTextViewText(R.id.widget_weekday_text, label)
                views.addView(R.id.widget_weekdays, cell)
            }

            views.removeAllViews(R.id.widget_days)
            val firstOffset = monthCal.get(Calendar.DAY_OF_WEEK) - 1
            val maxDay = monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val today = todayKey()
            for (week in 0 until 6) {
                val row = RemoteViews(context.packageName, R.layout.widget_day_row)
                for (col in 0 until 7) {
                    val index = week * 7 + col
                    val day = index - firstOffset + 1
                    val cell = RemoteViews(context.packageName, R.layout.widget_day_cell)
                    if (day in 1..maxDay) {
                        val key = dateKey(year, month, day)
                        cell.setTextViewText(R.id.widget_day_text, day.toString())
                        val assignedIds = data.assigned[key].orEmpty()
                        val hasSchedule = assignedIds.isNotEmpty()
                        val bg = when {
                            key == selected -> if (darkTheme) cellBg else Color.rgb(234,241,255)
                            else -> cellBg
                        }
                        cell.setInt(R.id.widget_day_text, "setBackgroundColor", bg)
                        cell.setTextColor(R.id.widget_day_text, if (key == selected) { if (darkTheme) Color.WHITE else Color.rgb(23, 32, 51) } else ink)
                        val names = assignedIds.mapNotNull { id -> data.configs.firstOrNull { it.id == id }?.name }
                        cell.setTextViewText(R.id.widget_day_labels, names.joinToString("\n"))
                        cell.setTextColor(R.id.widget_day_labels, if (darkTheme) Color.WHITE else Color.rgb(23,32,51))
                        cell.setTextViewText(R.id.widget_day_dot, if (hasSchedule) "•" else "")
                        cell.setTextColor(R.id.widget_day_dot, if (darkTheme) Color.rgb(100,181,246) else Color.rgb(40,102,216))
                        if (key == today) {
                            cell.setInt(R.id.widget_day_text, "setBackgroundResource", R.drawable.widget_today_border)
                        } else if (key == selected) {
                            cell.setInt(R.id.widget_day_text, "setBackgroundResource", R.drawable.widget_selected_border)
                        }
                        cell.setOnClickPendingIntent(R.id.widget_day_text, datePending(context, key))
                        cell.setOnClickPendingIntent(R.id.widget_day_dot, datePending(context, key))
                    } else {
                        cell.setTextViewText(R.id.widget_day_text, "")
                        cell.setTextViewText(R.id.widget_day_dot, "")
                        cell.setTextViewText(R.id.widget_day_labels, "")
                        cell.setViewVisibility(R.id.widget_day_text, View.INVISIBLE)
                    }
                    row.addView(R.id.widget_day_row, cell)
                }
                views.addView(R.id.widget_days, row)
            }

            val selectedCal = parseDate(selected)
            views.setTextViewText(R.id.widget_selected_title, SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(selectedCal.time))
            val serviceIntent = Intent(context, DutyCalendarConfigWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                this.data = android.net.Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            views.setRemoteAdapter(R.id.widget_configs, serviceIntent)
            views.setEmptyView(R.id.widget_configs, R.id.widget_configs_empty)
            views.setPendingIntentTemplate(R.id.widget_configs, configTemplatePending(context))
            manager.updateAppWidget(widgetId, views)
            manager.notifyAppWidgetViewDataChanged(widgetId, R.id.widget_configs)
        }

        private fun actionPending(context: Context, action: String, delta: Int, key: String): PendingIntent {
            val intent = Intent(context, DutyCalendarWidgetProvider::class.java).setAction(action).putExtra(EXTRA_DELTA, delta)
            return PendingIntent.getBroadcast(context, key.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        private fun datePending(context: Context, date: String): PendingIntent {
            val intent = Intent(context, DutyCalendarWidgetProvider::class.java).setAction(ACTION_DATE).putExtra(EXTRA_DATE, date)
            return PendingIntent.getBroadcast(context, date.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        private fun configTemplatePending(context: Context): PendingIntent {
            val intent = Intent(context, DutyCalendarWidgetProvider::class.java).setAction(ACTION_TOGGLE_CONFIG)
            return PendingIntent.getBroadcast(context, 19001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        }
        private fun todayKey() = dateKey(Calendar.getInstance())
        private fun parseDate(value: String): Calendar = Calendar.getInstance().apply {
            val p = value.split("-")
            if (p.size == 3) set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt())
        }
    }
}
