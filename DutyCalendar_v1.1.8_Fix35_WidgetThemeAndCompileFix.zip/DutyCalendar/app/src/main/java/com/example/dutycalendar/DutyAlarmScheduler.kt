package com.example.dutycalendar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object DutyAlarmScheduler {

    fun schedule(context: Context, dateKey: String, config: DutyConfig): Boolean {
        if (config.time.isBlank()) return false

        val triggerAtMillis = parseTriggerTime(dateKey, config.time) ?: return false
        if (triggerAtMillis <= System.currentTimeMillis()) return false

        val manager = context.getSystemService(AlarmManager::class.java)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !manager.canScheduleExactAlarms()
        ) return false

        val key = alarmKey(dateKey, config.id)
        val intent = Intent(context, DutyAlarmReceiver::class.java).apply {
            action = DutyAlarmReceiver.ACTION_DUTY_ALARM
            putExtra(AlarmSoundService.EXTRA_TONE_URI, config.toneUri)
            putExtra(AlarmSoundService.EXTRA_ALARM_TITLE, config.name)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            key,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                manager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
            true
        } catch (_: SecurityException) {
            false
        }
    }

    fun cancel(context: Context, dateKey: String, configId: Int) {
        val intent = Intent(context, DutyAlarmReceiver::class.java).apply {
            action = DutyAlarmReceiver.ACTION_DUTY_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmKey(dateKey, configId),
            intent,
            PendingIntent.FLAG_NO_CREATE or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        if (pendingIntent != null) {
            context.getSystemService(AlarmManager::class.java).cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun cancelAll(context: Context, assignments: Map<String, Set<Int>>) {
        assignments.forEach { (date, ids) ->
            ids.forEach { id -> cancel(context, date, id) }
        }
    }

    private fun alarmKey(dateKey: String, configId: Int): Int =
        ("$dateKey#$configId").hashCode() and 0x7fffffff

    private fun parseTriggerTime(dateKey: String, time: String): Long? {
        return try {
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                isLenient = false
            }.parse(dateKey) ?: return null

            val parts = time.trim().uppercase(Locale.US).split(Regex("\\s+"))
            val hm = parts[0].split(":")
            if (hm.size != 2) return null

            val hour12 = hm[0].toInt()
            val minute = hm[1].toInt()
            val period = parts.getOrNull(1) ?: return null
            if (hour12 !in 1..12 || minute !in 0..59 || period !in listOf("AM", "PM")) {
                return null
            }

            val hour24 = when {
                period == "AM" && hour12 == 12 -> 0
                period == "PM" && hour12 != 12 -> hour12 + 12
                else -> hour12
            }

            Calendar.getInstance().apply {
                this.time = date
                set(Calendar.HOUR_OF_DAY, hour24)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        } catch (_: Exception) {
            null
        }
    }
}
